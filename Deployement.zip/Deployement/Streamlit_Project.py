import streamlit as st



import app as da

import ml_deployement as ma



import warnings

warnings.filterwarnings("ignore")

def main():

    # EDA

    da.main()



    st.header("SVM Model Predictor")



    # Predictor

    ma.main()







if(__name__ == '__main__'):

    main()
